$(document).ready(function(){
    
    $('.owl-carousel').owlCarousel({
        margin: 15,
        items: 3,
        loop: true,
        autoplay: true, 
        autoplayTimeout: 2000,
        responsive: {
            0: {
                items: 1
            },
            767: {
                items: 1
            },
            991: {
                items: 2
            },
            1199: {
                items: 3
            }
            
        }
    });
});